import React, { useState } from 'react';

export default function App() {
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalOutput, setTerminalOutput] = useState('');

  const handleTerminalSubmit = (e) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;

    const outputLine = `sqlcloud@db-terminal:~$ ${terminalInput}\nResultado:\n[Simulado]\n`;
    setTerminalOutput(prev => prev + outputLine);
    setTerminalInput('');
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans">
      {/* Header */}
      <header className="bg-gray-800 shadow-md sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <svg className="w-8 h-8 text-blue-500" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <h1 className="text-xl font-bold">SQLCloud</h1>
          </div>
          <button className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition">
            Iniciar sesión
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-4">Panel de Control SQLCloud</h2>
          <p className="text-gray-300 mb-6">Gestiona tus bases de datos desde la nube.</p>
        </div>
      </section>

      {/* Terminal */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <h3 className="text-xl font-semibold mb-4">Terminal SQL Web</h3>
        <form onSubmit={handleTerminalSubmit} className="mb-4">
          <input
            type="text"
            value={terminalInput}
            onChange={(e) => setTerminalInput(e.target.value)}
            placeholder="Escribe tu consulta SQL..."
            className="w-full bg-gray-800 border border-gray-600 px-4 py-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </form>
        <pre className="bg-black p-4 rounded text-sm overflow-x-auto whitespace-pre-wrap h-64">
          {terminalOutput || "$ "}
        </pre>
      </section>
    </div>
  );
}